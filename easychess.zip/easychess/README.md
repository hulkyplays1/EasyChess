# EasyChess

A Pen created on CodePen.

Original URL: [https://codepen.io/Fatehveer-Singh/pen/zxvpEXd](https://codepen.io/Fatehveer-Singh/pen/zxvpEXd).

